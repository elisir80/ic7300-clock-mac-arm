#!/usr/bin/env python3
import argparse
import datetime as dt
import time
import sys
from typing import Callable, TextIO
import serial
from serial.tools import list_ports
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

FE = 0xFE
FD = 0xFD

def bcd(n: int) -> int:
    return ((n // 10) << 4) | (n % 10)

def unbcd(n: int) -> int:
    return ((n >> 4) * 10) + (n & 0x0F)

def civ_frame(rig: int, ctrl: int, *body: int) -> bytes:
    return bytes([FE, FE, rig, ctrl, *body, FD])

def port_label(port) -> str:
    parts = [port.device]
    if port.product:
        parts.append(port.product)
    elif port.description and port.description != "n/a":
        parts.append(port.description)
    if port.serial_number:
        parts.append(f"SN={port.serial_number}")
    return " | ".join(parts)

def print_ports(stream: TextIO = sys.stdout) -> None:
    ports = list(list_ports.comports())
    if not ports:
        print("No serial ports found.", file=stream)
        return
    for port in ports:
        print(port_label(port), file=stream)

def detect_port() -> str | None:
    ports = list(list_ports.comports())
    scored: list[tuple[int, object]] = []
    for port in ports:
        haystack = " ".join(
            part for part in [
                port.device,
                port.description,
                port.manufacturer,
                port.product,
                port.serial_number,
                port.hwid,
            ] if part
        ).lower()
        score = 0
        if "ic-7300" in haystack:
            score += 100
        if "icom" in haystack:
            score += 50
        if "cp210" in haystack:
            score += 10
        if "usbserial" in port.device.lower() or "usbmodem" in port.device.lower():
            score += 5
        if score:
            scored.append((score, port))
    if scored:
        scored.sort(key=lambda item: item[0], reverse=True)
        return scored[0][1].device

    serial_like = [
        port.device for port in ports
        if "usbserial" in port.device.lower() or "usbmodem" in port.device.lower()
    ]
    if len(serial_like) == 1:
        return serial_like[0]
    return None

def build_clock(args) -> tuple[str, Callable[[], dt.datetime]]:
    if args.timezone:
        try:
            tz = ZoneInfo(args.timezone)
        except ZoneInfoNotFoundError:
            raise ValueError(f"Unknown timezone: {args.timezone}")
        return args.timezone, lambda: dt.datetime.now(tz)
    if args.utc:
        return "UTC", lambda: dt.datetime.now(dt.timezone.utc)
    return "LOCAL", lambda: dt.datetime.now().astimezone()

def read_frame(ser: serial.Serial, wait_s: float = 0.25) -> bytes:
    time.sleep(wait_s)
    return ser.read_all()

def expect_ack(ser: serial.Serial, rig: int, ctrl: int, action: str, wait_s: float = 0.35) -> None:
    resp = read_frame(ser, wait_s)
    ok_sig = bytes([FE, FE, ctrl, rig, 0xFB, FD])
    ng_sig = bytes([FE, FE, ctrl, rig, 0xFA, FD])
    if ok_sig in resp:
        return
    if ng_sig in resp:
        raise RuntimeError(f"Radio rejected {action}.")
    raise RuntimeError(f"No ACK from radio after {action}: {resp.hex(' ')}")

def query_clock(ser: serial.Serial, rig: int, ctrl: int) -> tuple[dt.date, tuple[int, int]]:
    def query(*body: int) -> bytes:
        ser.reset_input_buffer()
        ser.write(civ_frame(rig, ctrl, *body))
        ser.flush()
        return read_frame(ser, 0.35)

    time_resp = query(0x1A, 0x05, 0x00, 0x95)
    date_resp = query(0x1A, 0x05, 0x00, 0x94)

    time_sig = bytes([FE, FE, ctrl, rig, 0x1A, 0x05, 0x00, 0x95])
    date_sig = bytes([FE, FE, ctrl, rig, 0x1A, 0x05, 0x00, 0x94])

    time_idx = time_resp.rfind(time_sig)
    date_idx = date_resp.rfind(date_sig)
    if time_idx < 0 or date_idx < 0:
        raise RuntimeError("No valid CI-V response from radio.")

    time_data = time_resp[time_idx + len(time_sig):]
    date_data = date_resp[date_idx + len(date_sig):]
    if len(time_data) < 3 or time_data[2] != FD:
        raise RuntimeError(f"Unexpected time response: {time_resp.hex(' ')}")
    if len(date_data) < 5 or date_data[4] != FD:
        raise RuntimeError(f"Unexpected date response: {date_resp.hex(' ')}")

    hour = unbcd(time_data[0])
    minute = unbcd(time_data[1])
    year = unbcd(date_data[0]) * 100 + unbcd(date_data[1])
    month = unbcd(date_data[2])
    day = unbcd(date_data[3])
    return dt.date(year, month, day), (hour, minute)

def main() -> int:
    p = argparse.ArgumentParser(description="IC-7300 clock sync via CI-V over USB serial.")
    p.add_argument("--port", help="Serial port. If omitted, tries to auto-detect the IC-7300.")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--set-date", action="store_true")
    p.add_argument("--local", action="store_true", help="Use local time. Kept for compatibility.")
    p.add_argument("--utc", action="store_true", help="Use UTC instead of local time.")
    p.add_argument("--timezone", help="Use a specific IANA timezone, e.g. Europe/Malta.")
    p.add_argument("--list-ports", action="store_true", help="List available serial ports and exit.")
    p.add_argument("--wait-minute", action="store_true", help="Wait for second 00 before setting the clock.")
    p.add_argument("--dry-run", action="store_true", help="Show the selected target time without sending anything.")
    p.add_argument("--no-verify", action="store_true", help="Skip the read-back verification after setting the clock.")
    args = p.parse_args()

    if args.list_ports:
        print_ports()
        return 0

    try:
        mode, now_dt = build_clock(args)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    port = args.port or detect_port()
    if not port:
        print("ERROR: Could not auto-detect the IC-7300 serial port.", file=sys.stderr)
        print("Available ports:", file=sys.stderr)
        print_ports(sys.stderr)
        return 2

    rig = 0x94
    ctrl = 0xE0

    print(f"Mode: {mode}", flush=True)
    print(f"Port: {port}", flush=True)
    if args.wait_minute:
        print("Waiting for top-of-minute...", flush=True)
        while True:
            now = now_dt()
            if now.second == 0:
                target = now.replace(second=0, microsecond=0)
                break
            time.sleep(0.05)
    else:
        now = now_dt()
        if now.second >= 30:
            now += dt.timedelta(minutes=1)
        target = now.replace(second=0, microsecond=0)
        print("Sync: immediate (nearest minute)", flush=True)

    hh = target.hour
    mm = target.minute

    time_cmd = civ_frame(
        rig, ctrl,
        0x1A, 0x05, 0x00, 0x95,
        bcd(hh), bcd(mm),
    )

    year = target.year
    cc = year // 100
    yy = year % 100
    date_cmd = civ_frame(
        rig, ctrl,
        0x1A, 0x05, 0x00, 0x94,
        bcd(cc), bcd(yy),
        bcd(target.month), bcd(target.day),
    )

    print(f"Setting {mode} time to {hh:02d}:{mm:02d}", flush=True)

    if args.dry_run:
        print("DRY RUN: no data sent", flush=True)
        return 0

    try:
        with serial.Serial(port, args.baud, timeout=0.5) as ser:
            if args.set_date:
                ser.write(date_cmd)
                ser.flush()
                expect_ack(ser, rig, ctrl, "date set")
            ser.write(time_cmd)
            ser.flush()
            expect_ack(ser, rig, ctrl, "time set")
            if not args.no_verify:
                radio_date, (radio_hh, radio_mm) = query_clock(ser, rig, ctrl)
    except serial.SerialException as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    if not args.no_verify:
        print(f"Radio now reports {radio_date.isoformat()} {radio_hh:02d}:{radio_mm:02d}", flush=True)
        if radio_date != target.date() or radio_hh != hh or radio_mm != mm:
            print("ERROR: radio time does not match requested value.", file=sys.stderr)
            return 1

    print("DONE", flush=True)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
