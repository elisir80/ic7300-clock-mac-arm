#!/bin/zsh
set -uo pipefail

SCRIPT_DIR=${0:A:h}
PORT="${IC7300_PORT:-}"
BAUD="${IC7300_BAUD:-115200}"
TIMEZONE="${IC7300_TIMEZONE:-Europe/Malta}"

typeset -a CANDIDATES

if [[ -n "${IC7300_PYTHON:-}" ]]; then
  CANDIDATES+=("${IC7300_PYTHON}")
fi

CANDIDATES+=(
  "$HOME/.pyenv/shims/python3"
  "$HOME/.pyenv/versions/3.10.3/bin/python3"
  "/opt/homebrew/bin/python3"
  "/usr/local/bin/python3"
  "/usr/bin/python3"
)

for candidate in "${CANDIDATES[@]}"; do
  if [[ -x "$candidate" ]] && "$candidate" -c 'import serial, zoneinfo' >/dev/null 2>&1; then
    PYTHON_BIN="$candidate"
    break
  fi
done

if [[ -z "${PYTHON_BIN:-}" ]]; then
  echo "ERRORE: impossibile trovare un interprete Python 3 con pyserial installato." >&2
  echo "Imposta IC7300_PYTHON oppure installa pyserial per python3." >&2
  exit 1
fi

ARGS=(
  --baud "$BAUD"
  --set-date
  --timezone "$TIMEZONE"
)

if [[ -n "$PORT" ]]; then
  ARGS+=(--port "$PORT")
fi

exec "$PYTHON_BIN" "$SCRIPT_DIR/ic7300_set_clock.py" "${ARGS[@]}" "$@"
